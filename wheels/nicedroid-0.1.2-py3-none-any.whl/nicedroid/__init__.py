"""nicedroid — run NiceGUI apps as Android APKs (Briefcase/Chaquopy).

Usage (Briefcase app module)::

    import nicedroid          # first import! applies Android patches
    from nicegui import ui

    @ui.page("/")
    def index():
        ui.label("Hello Android")

    def main():
        return nicedroid.app(port=8080, title="My App")

Importing this package applies the Android runtime patches (native-lib
preload, nicegui process-pool guard, signal guard) — a no-op on other
platforms. Import it *before* nicegui.
"""

from ._patches import IS_ANDROID, apply  # noqa: F401

apply()  # must run before the first nicegui/lxml import

from ._app import app  # noqa: E402,F401
from ._battery import request_exemption  # noqa: E402,F401

__version__ = "0.1.0"
__all__ = ["app", "apply", "request_exemption", "IS_ANDROID", "__version__"]
