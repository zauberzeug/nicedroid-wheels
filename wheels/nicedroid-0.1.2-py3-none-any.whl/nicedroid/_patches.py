"""Android runtime patches for running NiceGUI under Briefcase/Chaquopy.

All three patches are no-ops outside Android and idempotent. They are applied
automatically on ``import nicedroid`` — before that import, do not import
``nicegui`` (the lxml preload must happen before lxml's first import).

Each patch works around a concrete, device-verified issue
(see FINDINGS-M2-TIER1.md in the nicedroid repo):

1. **Native lib preload:** wheels from the nicedroid/Flet index ship C
   libraries (libxml2, libxslt, libyaml, ...) as separate wheels under
   ``requirements/opt/lib``; Chaquopy's linker does not search there, so
   ``lxml.etree`` etc. fail with ``dlopen ... not found``. We preload every
   ``.so`` in that directory with RTLD_GLOBAL (fixpoint loop → dependency
   order resolves itself).
2. **nicegui process pool:** ``ui.run()`` creates a ProcessPoolExecutor for
   ``run.cpu_bound``; Chaquopy has no ``_multiprocessing`` and raises
   ``OSError``, which NiceGUI's own guard (``except NotImplementedError``)
   does not catch → server startup dies. We broaden the guard; the pool stays
   ``None`` (``io_bound`` uses the thread pool). Obsolete once NiceGUI
   broadens its own except clause.
3. **signal guard:** apps may register signal handlers via ``app.on_startup``
   (e.g. nicetransfer's SIGTERM cleanup), which runs on the server thread;
   ``signal.signal`` raises ``ValueError`` off the main thread. We turn it
   into a logged no-op there.
"""

import ctypes
import os
import sys
import threading

IS_ANDROID = sys.platform == "android"

_applied = False


def _log(message: str) -> None:
    print(f"nicedroid: {message}", flush=True)  # Chaquopy routes this to logcat


def _preload_native_libs() -> None:
    """Load all shared libraries shipped under requirements/opt/lib."""
    anchor = None
    for module in ("orjson", "pydantic_core"):  # any extracted native package works
        try:
            anchor = __import__(module)
            break
        except ImportError:
            continue
    if anchor is None:
        return
    libdir = os.path.join(os.path.dirname(os.path.dirname(anchor.__file__)), "opt", "lib")
    if not os.path.isdir(libdir):
        return
    pending = sorted(f for f in os.listdir(libdir) if f.endswith(".so"))
    while pending:  # fixpoint: retry until no further lib can be loaded
        failed = []
        for name in pending:
            try:
                ctypes.CDLL(os.path.join(libdir, name), mode=ctypes.RTLD_GLOBAL)
                _log(f"preloaded {name}")
            except OSError:
                failed.append(name)
        if len(failed) == len(pending):
            _log(f"could not preload: {', '.join(failed)}")
            break
        pending = failed


def _patch_nicegui_process_pool() -> None:
    from nicegui import run as nicegui_run

    original_setup = nicegui_run.setup

    def safe_setup() -> None:
        try:
            original_setup()
        except Exception as exc:  # noqa: BLE001 — Chaquopy raises OSError here
            _log(f"process pool disabled: {type(exc).__name__}: {exc}")

    nicegui_run.setup = safe_setup


def _guard_signal_off_main_thread() -> None:
    import signal

    original_signal = signal.signal

    def safe_signal(signalnum, handler):
        if threading.current_thread() is threading.main_thread():
            return original_signal(signalnum, handler)
        _log(f"signal.signal({signalnum}) ignored off main thread")
        return None

    signal.signal = safe_signal


def apply() -> None:
    """Apply all Android patches (idempotent; no-op outside Android)."""
    global _applied
    if _applied or not IS_ANDROID:
        return
    _applied = True
    _preload_native_libs()
    _patch_nicegui_process_pool()
    _guard_signal_off_main_thread()
