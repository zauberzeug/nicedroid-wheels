# nicedroid (runtime package)

Runtime layer for running [NiceGUI](https://nicegui.io) apps as Android APKs
(via [Briefcase](https://briefcase.beeware.org)/Chaquopy). It hides the
Android-specific glue so an app module stays essentially a normal NiceGUI app.

```python
import nicedroid          # FIRST import — applies Android patches
from nicegui import ui

@ui.page("/")
def index():
    ui.label("Hello Android")

def main():                # Briefcase entry point
    return nicedroid.app(port=8080, title="My App")
```

## What it does

- **`nicedroid.app(...)`** — returns a `toga.App` that runs the NiceGUI server
  on a daemon thread and shows it in a native `toga.WebView`. Options: `port`,
  `host`, `url` (WebView target, e.g. with a token), `server` (a callable that
  runs its own `ui.run()`, for self-running scripts), `battery_exemption`,
  plus any `ui.run()` kwargs.
- **Android patches** (applied on import, no-ops elsewhere): preload native
  `.so` libraries shipped separately by the wheel index; broaden nicegui's
  process-pool guard (Chaquopy lacks `_multiprocessing`); make `signal.signal`
  a no-op off the main thread.
- **`nicedroid.request_exemption()`** — ask the user once to exempt the app
  from battery optimization (required so the server survives screen-off/Doze;
  see the project's FINDINGS-M2-TIER1.md). Needs the manifest permission:

  ```toml
  [tool.briefcase.app.<name>.android]
  permission."android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" = true
  ```

## App pyproject (Android section)

```toml
requires = ["toga-android~=0.5.0", "nicegui==3.14.0", "nicedroid==0.1.0"]
```

with the nicedroid wheel index configured (see
[nicedroid-wheels](https://github.com/zauberzeug/nicedroid-wheels)). The
Android patches assume Python 3.13 and the index's cp313/arm64 wheels.

Part of the nicedroid project — see the repository root for the toolchain plan
([TOOLCHAIN.md](../../TOOLCHAIN.md)).
