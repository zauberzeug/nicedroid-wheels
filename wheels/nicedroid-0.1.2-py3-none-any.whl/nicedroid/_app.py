"""Toga app factory: NiceGUI server on a daemon thread + native WebView."""

import socket
import sys
import threading
import time
import traceback

from . import _battery, _patches


def _log(message: str) -> None:
    print(f"nicedroid: {message}", flush=True)


def _wait_for_port(host: str, port: int, timeout: float) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.2)
    return False


def _hide_header(toga_app) -> None:
    """Hide Android's ActionBar (the native title header above the WebView).

    Hiding (instead of a NoActionBar theme) keeps toga's ActionBar references
    valid; desktop windows keep their normal titlebar.
    """
    if sys.platform != "android":
        return
    try:
        bar = toga_app._impl.native.getSupportActionBar()
        if bar is not None:
            bar.hide()
            _log("header hidden (pass header=True to keep it)")
    except Exception as exc:  # noqa: BLE001 — must never break app startup
        _log(f"hiding header failed: {type(exc).__name__}: {exc}")


def _hide_keyboard_on_start(toga_app) -> None:
    """Keep the soft keyboard closed on app start.

    Without an explicit soft-input mode Android sometimes restores the
    keyboard from the previously focused app; tapping an input field still
    opens it as usual.
    """
    if sys.platform != "android":
        return
    try:
        from android.view import WindowManager

        params = WindowManager.LayoutParams
        toga_app._impl.native.getWindow().setSoftInputMode(
            params.SOFT_INPUT_STATE_ALWAYS_HIDDEN | params.SOFT_INPUT_ADJUST_RESIZE
        )
    except Exception as exc:  # noqa: BLE001 — must never break app startup
        _log(f"hiding soft keyboard failed: {type(exc).__name__}: {exc}")


def app(
    *,
    port: int = 8080,
    host: str = "0.0.0.0",
    url: str | None = None,
    server=None,
    header: bool = False,
    battery_exemption: bool = True,
    startup_timeout: float = 40.0,
    formal_name: str | None = None,
    app_id: str | None = None,
    **ui_run_kwargs,
):
    """Return a toga.App that serves the NiceGUI app and shows it in a WebView.

    Two usage patterns:

    * **Pages defined in your module** (the normal case): import nicedroid
      first, define ``@ui.page(...)`` handlers, then ``return nicedroid.app()``
      from Briefcase's ``main()``. nicedroid calls ``ui.run(host, port,
      reload=False, show=False, **ui_run_kwargs)`` on a daemon thread.
    * **Self-running script** (e.g. a module that calls ``ui.run()`` itself):
      pass ``server=<callable>``; it is invoked on the server thread and is
      expected to block in its own ``ui.run()``.

    ``url`` overrides the WebView target (default ``http://127.0.0.1:{port}/``),
    e.g. to append a token. ``header`` controls Android's native title bar
    above the WebView; the default ``False`` gives the app the full screen
    (no-op on desktop). ``battery_exemption`` asks the user once to exempt
    the app from battery optimization — required for the server to stay
    reachable while the screen is off (see FINDINGS-M2-TIER1.md).
    """
    import toga

    def serve() -> None:
        try:
            _patches.apply()  # idempotent; already applied on import
            if server is not None:
                server()
            else:
                from nicegui import ui

                ui.run(host=host, port=port, reload=False, show=False, **ui_run_kwargs)
        except Exception as exc:  # noqa: BLE001 — surface crashes in logcat
            _log(f"SERVER CRASHED: {type(exc).__name__}: {exc}")
            traceback.print_exc()

    class NiceDroidApp(toga.App):
        def startup(self) -> None:
            _hide_keyboard_on_start(self)
            threading.Thread(target=serve, daemon=True, name="nicedroid-server").start()
            up = _wait_for_port("127.0.0.1", port, startup_timeout)
            _log(f"server ready={up} on port {port}")
            if battery_exemption:
                _battery.request_exemption()
            self.web_view = toga.WebView(url=url or f"http://127.0.0.1:{port}/")
            self.main_window = toga.MainWindow(title=self.formal_name)
            self.main_window.content = self.web_view
            self.main_window.show()
            if not header:
                _hide_header(self)

    kwargs = {}
    if formal_name is not None:
        kwargs["formal_name"] = formal_name
    if app_id is not None:
        kwargs["app_id"] = app_id
    return NiceDroidApp(**kwargs)
