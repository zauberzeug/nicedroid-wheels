"""Battery-optimization exemption (the screen-off gate, device-verified).

Without this exemption, Doze suspends the app's network as soon as the screen
turns off while unplugged — the process survives but the server becomes
unreachable. With it, the server stays reachable (verified on Android 11 and,
bindingly, Android 14 — no foreground service required).

Requires ``android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`` in the
manifest (Briefcase: ``permission."android...." = true`` in the android
section); without it we fall back to opening the battery settings list.
"""

import sys

IS_ANDROID = sys.platform == "android"


def _log(message: str) -> None:
    print(f"nicedroid: {message}", flush=True)


def request_exemption() -> bool | None:
    """Ask the user (once) to exempt the app from battery optimization.

    Returns True if already exempt, False if the system dialog was opened,
    None if not on Android or the request failed.
    """
    if not IS_ANDROID:
        return None
    try:
        from java import cast  # Chaquopy bridge

        from android.app import ActivityThread
        from android.content import Context, Intent
        from android.net import Uri
        from android.os import PowerManager
        from android.provider import Settings

        context = ActivityThread.currentApplication()
        package = str(context.getPackageName())
        power = cast(PowerManager, context.getSystemService(Context.POWER_SERVICE))
        if power.isIgnoringBatteryOptimizations(package):
            _log("battery exemption already granted")
            return True

        intent = Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse(f"package:{package}"),
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        _log("battery exemption dialog opened")
        return False
    except Exception as exc:  # noqa: BLE001 — must never break app startup
        _log(f"battery exemption request failed: {type(exc).__name__}: {exc}")
        try:  # fallback: at least open the settings list
            from android.app import ActivityThread
            from android.content import Intent
            from android.provider import Settings

            intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ActivityThread.currentApplication().startActivity(intent)
            _log("opened battery optimization settings instead")
        except Exception:  # noqa: BLE001
            pass
        return None
