raise ImportError(
    "uvloop is a nicedroid Android stub (no real Android wheel exists; "
    "not needed at runtime — uvicorn/nicegui fall back cleanly). "
    "See zauberzeug/nicedroid wheelindex/README.md."
)
