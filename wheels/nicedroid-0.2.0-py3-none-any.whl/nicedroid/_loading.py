"""Embedded loading page: logo + animated bars until the server responds.

Shown via ``WebView.set_content`` the moment the window appears; a background
thread flips the WebView to the real URL once the port accepts connections
(see ``_app.py``). Pure inline CSS/HTML — no assets, no JS required, renders
on old WebViews too.
"""

from ._logo import LOGO_PNG_B64


def default_loading_html(title: str = "") -> str:
    """Return the default loading page (NiceGUI logo, pulsing bars, app name)."""
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  html, body {{ height: 100%; margin: 0; background: #ffffff; }}
  body {{ display: flex; flex-direction: column; align-items: center;
          justify-content: center; gap: 28px;
          font-family: -apple-system, Roboto, "Segoe UI", sans-serif; }}
  img {{ width: 96px; height: 96px; }}
  .bars {{ display: flex; gap: 6px; height: 28px; align-items: flex-end; }}
  .bars div {{ width: 7px; background: #222222; border-radius: 3px;
               animation: pulse 1s ease-in-out infinite; }}
  .bars div:nth-child(2) {{ animation-delay: .15s; }}
  .bars div:nth-child(3) {{ animation-delay: .3s; }}
  .bars div:nth-child(4) {{ animation-delay: .45s; }}
  .bars div:nth-child(5) {{ animation-delay: .6s; }}
  @keyframes pulse {{ 0%, 100% {{ height: 8px; opacity: .35; }}
                      50%       {{ height: 28px; opacity: 1; }} }}
  p {{ color: #666666; margin: 0; font-size: 15px; }}
</style></head>
<body>
  <img src="data:image/png;base64,{LOGO_PNG_B64}" alt="">
  <div class="bars"><div></div><div></div><div></div><div></div><div></div></div>
  <p>{title}</p>
</body></html>"""
