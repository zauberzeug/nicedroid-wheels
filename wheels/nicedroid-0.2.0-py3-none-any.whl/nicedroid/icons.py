"""Icon generator: one source image -> all Briefcase icon sizes.

Runs on the developer machine, not on the device. Needs Pillow, shipped as
the ``icons`` extra::

    pip install "nicedroid[icons]" --extra-index-url https://zauberzeug.github.io/nicedroid-wheels/simple/
    nicedroid-icons my-icon.png          # writes icons/appicon-*.png

Run inside a project generated from the nicedroid template to replace the
default NiceGUI icons in ``icons/``. Two styles:

* default: the source is fit onto a rounded square / circle (``--bg`` color) —
  right for logos with transparent background,
* ``--full``: the source fills the icon edge-to-edge (center-cropped; the
  round variant gets a circular mask) — right for artwork with its own
  background.
"""

import argparse
import sys
from pathlib import Path

# Briefcase icon targets (see the android-gradle template's briefcase.toml
# plus generic sizes for the desktop platforms).
LAUNCHER_SIZES = (48, 72, 96, 144, 192)  # square + round
ADAPTIVE_SIZES = (108, 162, 216, 324, 432)  # transparent, 66% safe zone
SPLASH_SIZES = (320, 480, 640, 960, 1280)  # named square-<size> by Briefcase
GENERIC_SIZES = (16, 32, 64, 128, 256, 512, 1024)

SUPERSAMPLE = 4  # draw shapes at 4x and scale down for clean edges


def _require_pillow():
    try:
        from PIL import Image, ImageDraw  # noqa: F401

        return Image, ImageDraw
    except ImportError:
        sys.exit(
            "Pillow fehlt — Installation: pip install 'nicedroid[icons]' "
            "--extra-index-url https://zauberzeug.github.io/nicedroid-wheels/simple/"
        )


def _fit(image, box_px: int):
    """Return the source scaled to fit into box_px x box_px (aspect kept)."""
    from PIL import Image

    scale = box_px / max(image.width, image.height)
    size = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
    return image.resize(size, Image.LANCZOS)


def _cover(image, size: int):
    """Return the source scaled + center-cropped to fill size x size."""
    from PIL import Image

    scale = size / min(image.width, image.height)
    scaled = image.resize(
        (max(size, round(image.width * scale)), max(size, round(image.height * scale))),
        Image.LANCZOS,
    )
    left = (scaled.width - size) // 2
    top = (scaled.height - size) // 2
    return scaled.crop((left, top, left + size, top + size))


def _paste_centered(canvas, content) -> None:
    canvas.alpha_composite(
        content,
        ((canvas.width - content.width) // 2, (canvas.height - content.height) // 2),
    )


def _shape_icon(source, size: int, bg: str, shape: str, content_ratio: float):
    """Source fit onto a rounded square ('square') or circle ('round')."""
    from PIL import Image, ImageDraw

    s = size * SUPERSAMPLE
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    if shape == "round":
        draw.ellipse([0, 0, s - 1, s - 1], fill=bg)
    else:
        draw.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * 0.2), fill=bg)
    _paste_centered(img, _fit(source, int(s * content_ratio)))
    return img.resize((size, size), Image.LANCZOS)


def _full_icon(source, size: int, shape: str):
    """Source fills the icon; 'round' gets a circular alpha mask."""
    from PIL import Image, ImageDraw

    img = _cover(source, size)
    if shape == "round":
        s = size * SUPERSAMPLE
        mask = Image.new("L", (s, s), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, s - 1, s - 1], fill=255)
        img.putalpha(mask.resize((size, size), Image.LANCZOS))
    return img


def _transparent_icon(source, size: int, content_ratio: float):
    """Source fit onto a fully transparent canvas (adaptive/splash)."""
    from PIL import Image

    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    _paste_centered(img, _fit(source, int(size * content_ratio)))
    return img


def generate(
    source_path: Path,
    out_dir: Path,
    *,
    prefix: str = "appicon",
    bg: str = "#ffffff",
    full: bool = False,
) -> int:
    """Write all icon variants to out_dir; returns the number of files."""
    Image, _ = _require_pillow()
    source = Image.open(source_path).convert("RGBA")
    if max(source.width, source.height) < 512:
        print(
            f"Warnung: Quelle ist nur {source.width}x{source.height}px — "
            "für Splash-Größen bis 1280px besser >= 1024px verwenden.",
            file=sys.stderr,
        )
    out_dir.mkdir(parents=True, exist_ok=True)

    def squareish(size: int, shape: str):
        if full:
            return _full_icon(source, size, shape)
        return _shape_icon(source, size, bg, shape, 0.76 if shape == "square" else 0.68)

    count = 0
    for size in LAUNCHER_SIZES:
        squareish(size, "square").save(out_dir / f"{prefix}-square-{size}.png")
        squareish(size, "round").save(out_dir / f"{prefix}-round-{size}.png")
        count += 2
    for size in ADAPTIVE_SIZES:
        _transparent_icon(source, size, 0.60).save(out_dir / f"{prefix}-adaptive-{size}.png")
        count += 1
    for size in SPLASH_SIZES:
        _transparent_icon(source, size, 0.60).save(out_dir / f"{prefix}-square-{size}.png")
        count += 1
    for size in GENERIC_SIZES:
        squareish(size, "square").save(out_dir / f"{prefix}-{size}.png")
        count += 1
    squareish(512, "square").save(out_dir / f"{prefix}.png")
    return count + 1


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="nicedroid-icons",
        description="Erzeugt aus einer Quellgrafik alle Briefcase-Icon-Größen "
        "(Launcher square/round, adaptive, Splash, Desktop).",
    )
    parser.add_argument("source", type=Path, help="Quellbild (PNG empfohlen, >= 1024px)")
    parser.add_argument("--out", type=Path, default=Path("icons"),
                        help="Zielverzeichnis (Default: icons/)")
    parser.add_argument("--prefix", default="appicon",
                        help="Dateinamen-Präfix (Default: appicon, wie im Template)")
    parser.add_argument("--bg", default="#ffffff",
                        help="Hintergrundfarbe der Box/Kreis-Icons (Default: #ffffff)")
    parser.add_argument("--full", action="store_true",
                        help="Quelle füllt das Icon randlos (statt Box mit --bg)")
    args = parser.parse_args(argv)

    count = generate(args.source, args.out, prefix=args.prefix, bg=args.bg, full=args.full)
    print(f"{count} Icons -> {args.out}/{args.prefix}*.png")


if __name__ == "__main__":
    main()
